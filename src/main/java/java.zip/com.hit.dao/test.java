//*
package main.java.com.hit.dao;
 //*/

import main.java.com.hit.dm.DataModel;

public class test {
    public static void main(String[] args) {
     DaoFileImpl<String> tes1=new DaoFileImpl<String>("testfile.obj");

     DataModel<String> dm1 = new DataModel((long) 1,"ab");
     DataModel<String> dm2= new DataModel((long) 2,"ac");
    tes1.save(dm1);
     tes1.save(dm2);

     dm1=tes1.find(1L);
     dm2=tes1.find(2L);

     System.out.println(dm2.getDataModelId());

//    tes1.Pages<String>.

    }
}
//*/

