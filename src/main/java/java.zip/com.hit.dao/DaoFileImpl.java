package main.java.com.hit.dao;

import main.java.com.hit.dm.DataModel;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class DaoFileImpl<T>  implements IDao<Long,DataModel<T>> {
    private String filename;
    private ObjectInputStream in;
//    private ObjectOutputStream out;
    private ObjectOutputStream out;

    protected Map<Long,DataModel<T>> Pages;

    public  DaoFileImpl(String filename){
        this.filename=filename;
        try {
            out=new ObjectOutputStream(new FileOutputStream(filename));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void delete(DataModel<T> entity) {
       // Pages.remove(entity);


    }

    @Override
    public DataModel<T> find(Long aLong) {
     //  if(Pages.containsKey(aLong))
     //       return Pages.get(aLong);
    DataModel<T> page=null;
        try {
            in=new ObjectInputStream(new FileInputStream(filename));

            //            NoHeaderObjectOutPutStream
            while((page= (DataModel<T>) in.readObject()) != null )
            {
         //       System.out.println(page.getDataModelId());
                if(page.getDataModelId()==aLong)
                    return page;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void save(DataModel<T> entity){
        try {
            out= new NoHeaderObjectOutPutStream(new FileOutputStream(filename,true));
            out.writeObject(entity);
//            Pages.put(entity.getDataModelId(),entity);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
