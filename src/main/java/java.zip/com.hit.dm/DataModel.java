package main.java.com.hit.dm;

import java.util.Map;

public class DataModel <T> extends Object implements  java.io.Serializable {
    private long  id;
    private T content;
   public  DataModel(Long id, T content){
      this.id=id;
      this.content=content;
    }
    public Long	getDataModelId(Long id){ return this.id;}

//    T getContent(){return content;}
 void setContent(T content){this.content=content;}


/*
    boolean equal(java.lang.Object obj){ return false;}




   public int hashCode(){return  (int)id; }//null;}

    void setDataModelid(java.lang.Long id ){
        this.id=id;
    }

//    java.lang.String toString(){ }
*/
}

