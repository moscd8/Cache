package main.java.com.hit.memory;

import main.java.IAlgoCache;
import main.java.com.hit.dao.IDao;
import main.java.com.hit.dm.DataModel;

import java.util.ArrayList;
import java.util.List;

public class CacheUnit<T> extends Object {

    private IAlgoCache cache;
    private DataModel<T> hd;
//    private Map<Long,DataModel<byte[]>> HD;
    public   CacheUnit(IAlgoCache<Long,DataModel<T>> algo, IDao<java.io.Serializable, DataModel<T>> dao){
        cache=algo;
        hd= (DataModel<T>) dao;
    }

    Long getDataModels(Long[] ids){
        List<DataModel<T>> list=new ArrayList<>();
        for (long id : ids){
            Long page= (DataModel<T>) cache.getElement(id);
            if(page!= null)
            {
                list.add(page);
            }
            else{
 //               DataModel<T> page= (DataModel<T>) cache.getElement(id);

                if(hd.getDataModelId(id)!=null){
                   page=hd.getDataModelId(id);
                    return     page;
                }
            }

        }
    }
}
